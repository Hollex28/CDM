package com.example.jcruizg.igucomponentesbasicos;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


/*
 ** ESTA ACTIVIDAD SIMPLEMENTE MUESTRA UN LAYOUT CON INFORMACIÓN RELATIVA AL AUTOR DE ESTA IMPLEMENTACIÓN
 */
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
