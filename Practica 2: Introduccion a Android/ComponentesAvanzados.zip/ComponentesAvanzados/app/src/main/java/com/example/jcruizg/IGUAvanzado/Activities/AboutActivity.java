package com.example.jcruizg.IGUAvanzado.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.jcruizg.IGUAvanzado.R;


/*
 ** ESTA ACTIVIDAD SIMPLEMENTE MUESTRA UN LAYOUT CON INFORMACIÓN RELATIVA AL AUTOR DE ESTA IMPLEMENTACIÓN
 */
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
